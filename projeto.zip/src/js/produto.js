$('[name=tamanho]').on('input', function(){
		$('[name=valortamanho]').text(this.value);
});